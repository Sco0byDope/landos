<?php
require("modules/phpmailer.php");

$send_email = "warlok72rus@mail.ru"; // Первый получатель сообщения
$from_name  = "[Landing] Организация детских праздников"; // ОТ кого 
$from_address = "zayvka@dpraz123123.ru"; // ОТ кого 

$subject = "Заявка на Организацию детского праздника";
$message = " --- Заявка на Организацию детского праздника! ---";

if(!$_GET['cart']){

	$input['names'] = array(
		"ccustom_U5480", "custom_U649", "custom_U6912", "custom_U10095", "custom_U11194", "custom_U9774", "custom_U10297", "custom_U10301", "custom_U11977", "custom_U9976", "custom_U10405", "custom_U11394", "custom_U9869", "custom_U10183", "custom_U11297", "custom_U11757", "custom_U7880", "custom_U12132", "custom_U9455", "custom_U9581","custom_U12370", "custom_U5480", "custom_U13011",
		"name"=>"Имя"
	);
	$input['phones'] = array(
		"custom_U5489", "custom_U7876", "custom_U12128", "custom_U9445", "custom_U9590", "custom_U643", "custom_U6902", "custom_U10088", "custom_U11185", "custom_U9767", "custom_U10301", "custom_U11508", "custom_U11970", "custom_U9980", "custom_U10410", "custom_U11406", "custom_U9873", "custom_U10190", "custom_U11306", "custom_U11768", "custom_U12411", "custom_U13020", "custom_U12376",
		"name"=>"Телефон"
	);
	$input['emails'] = array(
		"custom_U639", "custom_U6908", "custom_U10083", "custom_U11190", "custom_U9762", "custom_U10309", "custom_U11516","custom_U11966", "custom_U9988", "custom_U10401", "custom_U11402", "custom_U9881", "custom_U10195", "custom_U11301", "custom_U11763", "custom_U12417","Email",
		"name"=>"E-mail"
	);
	
	foreach ($_REQUEST as $key => $value)
	{
		foreach ($input as $var)
		{
			if ( $value != '' && in_array($key, $var) )
			{
				$message .= "<br>" . $var["name"] . ": " . htmlspecialchars(trim($value));
				continue;
			}
		}

	}
}
else
{
	$data = json_decode($_REQUEST['data'], true);

	$message = "Имя: " . $data['name'];
	$message .= "\nТелефон: " . $data['phone'];
	$message .= "\nE-mail: " .$data['email'];

	$message .= "\nЗаказ аниматоров:\n\t";
	foreach ($data['items'] as $item) {
		$message .= $item['name'] ."\n\t";
	}
}

if (isset($_REQUEST)){

	if ( !count($errors) )
	{
		$mail = new PHPMailer();

		$mail->From      = $from_address;
		$mail->CharSet   = 'UTF-8';
		$mail->ContentType = 'text/html';
		$mail->FromName  = $from_name;
		$mail->Subject   = $subject;
		$mail->Body      = $message;
		$mail->AddAddress( $send_email);
		$mail->IsHTML(true);
		$mail->send();
	} 
}
?>
<script type="text/javascript">
	window.location = "../thanks/";
</script>