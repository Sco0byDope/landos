(function () {
    // Globals.
    var app = {}
    window.cartjs = app

    // jQuery in some cases may be unavailable and will be loaded dynamically.
    var $ = null

    // # Helpers.
    //
    // Common helpers.
    var timeout = 3000
    var bind = function (fn, _this) {
        return function () {
            return fn.apply(_this, arguments)
        }
    }
    var bindAll = function () {
        var obj = arguments[arguments.length - 1]
        for (var i = 0; i < (arguments.length - 1); i++) {
            var fname = arguments[i]
            var fn = obj[fname]
            if (!fn) throw new Error('no function ' + fname + ' for object ' + obj + ' !')
            obj[fname] = bind(fn, obj)
        }
    }
    var p = bind(console.log, console)
    var find = function (array, fn) {
        for (var i = 0; i < array.length; i++) if (fn(array[i])) return i
        return -1
    }
    var each = function (array, fn) {
        for (var i = 0; i < array.length; i++) fn(array[i], i)
    }
    var eachInObject = function (obj, fn) {
        for (k in obj) if (obj.hasOwnProperty(k)) fn(k)
    }
    var isObjectEmpty = function (obj) {
        for (k in obj) if (obj.hasOwnProperty(k)) return false
        return true
    }
    var extend = function () {
        var a = arguments[0]
        for (var i = 1; i < arguments.length; i++) {
            var b = arguments[i]
            eachInObject(b, function (k) {
                a[k] = b[k]
            })
        }
        return a
    }
    var debug = function () {
        // var args = Array.prototype.slice.call(arguments)
        // args.unshift('cartjs')
        // console.info.apply(console, args)
    }


    // Cross domain request.
    var server = {}
    server.send = function (method, url, data, callback) {
        // if(url.indexOf('ordersfix') > -1){
        //   url = 'https://cart.creatura.club:8305/v4/';
        // }
        var domain = window.location.hostname;
        domain = domain.replace('www.', '');

        if (!window.FormData || !window.XMLHttpRequest)
            return callback(new Error("Your browser doesn't support that feature, please update it."))
        var formData = new FormData()
        data.domain = domain;
        formData.append('data', JSON.stringify(data))
        var xhrTimeoutId = 0;
        var responded = false
        var xhr = new XMLHttpRequest()
        xhr.open(method.toUpperCase(), url);
        xhr.onreadystatechange = function () {
            if (responded) return
            if (xhr.readyState == 4) {
                responded = true;
                console.log('response:');
                console.log(xhr.responseText);
                callback(xhr.responseText);
                return;
                if (xhr.status == 200) {
                    if (xhr.responseText == 'licenseError') {
                        callback(xhr.responseText)
                        return;
                    }
                    else {
                        callback(null, JSON.parse(xhr.responseText))
                    }
                }
                else callback(new Error(xhr.responseText))
            }
            clearTimeout(xhrTimeoutId);
        }
        xhrTimeoutId = setTimeout(function () {
            if (responded) return
            responded = true
            callback(new Error("no response from " + url + "!"))
        }, timeout)
        debug(method, url, data)
        xhr.send(formData)
    }
    server.post = function (url, data, callback) {
        this.send('post', url, data, callback)
    }

    //server.ajax = function(url, )
    server.license = true;


   

    // Async helper to simplify error handling in callbacks.
    var fork = function (onError, onSuccess) {
        return function () {
            var args = Array.prototype.slice.call(arguments, 1)
            if (arguments[0]) onError(arguments[0])
            else onSuccess.apply(null, args)
        }
    }
    var once = function (fn) {
        var called = false
        return function () {
            if (!called) {
                called = true
                return fn.apply(this, arguments)
            }
        }
    }

    // Load CSS dynamically. There's no way to determine when stylesheet has been loaded
    // so we using hack - define `#my-css-loaded {position: absolute}` rule in stylesheet
    // and the `callback` will be called when it's loaded.
    var loadCss = function (url, cssFileId, callback) {
        // CSS in IE can be added only with `createStyleSheet`.
        if (document.createStyleSheet) document.createStyleSheet(url)
        else $('<link rel="stylesheet" type="text/css" href="' + url + '" />').appendTo('head')

        // There's no API to notify when styles will be loaded, using hack to
        // determine if it's loaded or not.
        var loaded = false
        var $testEl = $('<div id="' + cssFileId + '" style="display: none"></div>').appendTo('body')
        var interval = 10
        var time = 0
        var checkIfStyleHasBeenLoaded = function () {
            if ($testEl.css('position') === 'absolute') {
                loaded = true
                $testEl.remove()
                return callback()
            }
            if (time >= timeout) return callback(new Error("can't load " + url + "!"))
            time = time + interval
            setTimeout(checkIfStyleHasBeenLoaded, interval)
        }
        setTimeout(checkIfStyleHasBeenLoaded, 0)
    }

    // Load JS dynamically, `$.getScript` can't be used because there may be no `jQuery`.
    var loadJs = function (url, callback) {
        var script = document.createElement('script')
        script.type = 'text/javascript'
        script.async = true
        var responded = false
        script.onreadystatechange = script.onload = function () {
            var state = script.readyState
            if (responded) return
            if (!state || /loaded|complete/.test(state)) {
                responded = true
                callback()
            }
        }
        script.src = url
        document.body.appendChild(script)
        setTimeout(function () {
            if (responded) return
            responded = true
            callback(new Error("can't load " + url + "!"))
        }, timeout)
    }

    // Loading jQuery if it's not already loaded.
    var requireJQuery = function (jQueryUrl, callback) {
        if (window.jQuery) callback(null, window.jQuery)
        else loadJs(jQueryUrl, fork(callback, function () {
            if (!window.jQuery) return callback(new Error("can't load jQuery!"))
            callback(null, window.jQuery)
        }))
    }

    // Template helpers.
    app.templates = {}
    app.template = function (name, fn) {
        this.templates[name] = function () {
            var buff = []
            var args = Array.prototype.slice.call(arguments)
            args.unshift(function (str) {
                buff.push(str)
            })
            fn.apply(null, args)
            return buff.join("\n")
        }
    }
    // Render template - `render(name, args...)`.
    app.render = function () {
        var args = Array.prototype.slice.call(arguments, 1)
        return this.templates[arguments[0]].apply(null, args)
    }

    // Helper to escape HTML.
    var escapeHtml = function (str) {
        return $('<div/>').text(str).html()
    }
    // var escapeId = function(str){return str.replace()}

    // Storage, for now just using `localStorage` and ignoring old browser that doesn't
    // support it, later will be updated to support older browsers also.
    var db = {
        get: function (key) {
            return window.localStorage.getItem(key)
        },
        set: function (key, value) {
            window.localStorage.setItem(key, value)
        },
        remove: function (key) {
            window.localStorage.removeItem(key)
        }
    }

    app.number_format = function (number, decimals, dec_point, thousands_sep) {  // Format a number with grouped thousands
        //
        // +   original by: Jonas Raoni Soares Silva (//www.jsfromhell.com)
        // +   improved by: Kevin van Zonneveld (//kevin.vanzonneveld.net)
        // +   bugfix by: Michael White (//crestidg.com)

        var i, j, kw, kd, km;

        // input sanitation & defaults
        if (isNaN(decimals = Math.abs(decimals))) {
            decimals = 2;
        }
        if (dec_point == undefined) {
            dec_point = ",";
        }
        if (thousands_sep == undefined) {
            thousands_sep = ".";
        }

        i = parseInt(number = (+number || 0).toFixed(decimals)) + "";

        if ((j = i.length) > 3) {
            j = j % 3;
        } else {
            j = 0;
        }

        km = (j ? i.substr(0, j) + thousands_sep : "");
        kw = i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thousands_sep);
        //kd = (decimals ? dec_point + Math.abs(number - i).toFixed(decimals).slice(2) : "");
        kd = (decimals ? dec_point + Math.abs(number - i).toFixed(decimals).replace(/-/, 0).slice(2) : "");


        return km + kw + kd;
    }

    // # Translation.
    app.translation = {}
    // Performs both key lookup and substring replacement with values from options.
    // Replaces all occurences of `#{key}` in string with corresponding values from
    // `options[key]`
    //
    //   app.translation.welcomeLetter = 'Welcome #{user}'
    //
    //   t('welcomeLetter', {user: 'Jim Raynor'}) => 'Welcome Jim Raynor'
    //
    // It also does pluralization if option `count` provided.
    //
    //   app.translation.cartLabelOne = '#{count} item'
    //   app.translation.cartLabelMany = '#{count} items'
    //
    //   t('cartLabel', {count: 1}) => '1 item'
    //   t('cartLabel', {count: 2}) => '2 items'
    //
    var t = function (key, options) {
        options = options || {}
        if ('count' in options) key = key + app.translation.pluralize(options.count)
        str = app.translation[key] || ('no translation for ' + key)
        eachInObject(options, function (k) {
            str = str.replace(new RegExp('\#\{' + k + '\}', 'g'), options[k])
        })
        return str
    }

    // # Minimalistic version of heart of Backbone.js - Events / Observer Pattern.
    var Events = function (obj) {
        obj.on = function () {
            var fn = arguments[arguments.length - 1]
            for (var i = 0; i < (arguments.length - 1); i++) {
                var name = arguments[i]
                this.subscribers = this.subscribers || {};
                (this.subscribers[name] = this.subscribers[name] || []).push(fn)
            }
        }
        obj.trigger = function () {
            var event = arguments[0]
            var args = Array.prototype.slice.call(arguments, 1)
            debug(event, args)
            if (!this.subscribers) return
            var list = this.subscribers[event] || []
            for (var i = 0; i < list.length; i++) list[i].apply(null, args)
        }
        obj.off = function () {
            delete this.subscribers
        }
    }

    // # Assembling and starting application.
    //
    // Adding events to `app`.
    Events(app)

    // Loading CSS & JS resources.
    app.loadResources = function (callback) {
        var baseUrl = this.baseUrl
        var language = this.language

        requireJQuery(baseUrl + '/vendor/jquery-1.10.2.js', fork(callback, function (jQuery) {
            $ = jQuery

            // Loading CSS and JS.
            callback = once(callback)
            var count = 0
            var done = function (err) {
                count = count + 1
                if (err) callback(err)
                if (count == 3) callback()
            }

            loadCss(baseUrl + '/vendor/bootstrap-3.0.2/css/bootstrap-widget.css'
                , 'bootstrap-widget-loaded', fork(callback, function () {
                    loadCss(baseUrl + '/cart.css', 'cart-loaded', done)
                }))

            loadJs(baseUrl + '/vendor/bootstrap-3.0.2/js/bootstrap.js', done)
            loadJs(baseUrl + '/languages/' + language + '.js', done)
        }))
    }

    // Initialization.
    app.languageShortcuts = {en: 'english', ru: 'russian'}
    app.initialize = function (options, callback) {
        // Parsing arguments.
        options = options || {}
        callback = callback || function (err) {
                if (err) console.error(err.message || err)
            }
        //console.log(options);
        // Options.
        this.yandex = {
            yandexID: false,
            reachOrder: false,
            reachPurchase: false,
        }

        if (options.positionPopover == 'left' || options.positionPopover == 'right') {
            this.positionPopover = options.positionPopover;
        }
        else {
            this.positionPopover = 'center';
        }
        this.Paycurrency = {
            '$': 'USD',
            '€': 'EUR',
            'Руб': 'RUB',
            '¥': 'JPY',
            'CHF': 'CHF',
        }


        if (options.yandex) {
            this.yandex = {
                yandexID: options.yandex.yandexID || false,
                reachOrder: options.yandex.reachOrder || false,
                reachPurchase: options.yandex.reachPurchase || false
            }
        }
        this.google = {
            reachPurchase: {
                category: false,
                action: false,
                name: false,
                value: false,
            },
            reachOrder: {
                category: false,
                action: false,
                name: false,
                value: false,
            },
        }

        this.paysystem = {
            home: false,
            paypal: false,
            yandex: false,
            bankDetails: false,
            robokassa: false,
            yandexkassa: false,
            unifiedwallet: false,
            webpay: false,
            privat24: false,
        }


        this.deliveryInternals = {
            show: false,
            items: [],
            recalculateTotalSum: false,
        }

        this.deliveryCount = 0;

        if (options.deliveryInternals) {
            this.deliveryInternals = options.deliveryInternals;

            if (this.deliveryInternals.items) {
                for (var key in this.deliveryInternals.items) {
                    if (this.deliveryInternals.items[key].show
                        && this.deliveryInternals.items[key].name
                        && this.deliveryInternals.items[key].price != undefined) {
                        this.deliveryCount++;
                    }
                }
            }
        }
        this.minSum = 0;
        if (options.minSum) {
            this.minSum = options.minSum;
        }

        this.minSumOn = options.minSumOn || false;

        this.basketAnimation = options.basketAnimation || false;

        if (options.aboutShop) {
            this.aboutShop = options.aboutShop;
        }
        this.phoneMask = "+9 (999) 999 99 99";
        if (options.phoneMask) {
            this.phoneMask = options.phoneMask;
        }

        this.payCount = 0;

        // if (options.paysystem){
        //   this.paysystem = {
        //     home: options.paysystem.home || true,
        //     paypal: (options.paysystem.paypal) || false,
        //     yandex: (options.paysystem.yandex) || false,
        //     bankDetails: (options.paysystem.bankDetails) || false,
        //     robokassa: (options.paysystem.robokassa) || false,
        //     yandexkassa: (options.paysystem.yandexkassa) || false,
        //     unifiedwallet: (options.paysystem.unifiedwallet) || false,
        //     webpay: (options.paysystem.webpay) || false,
        //     privat24: (options.paysystem.privat24) || false,
        //   }
        // }

        // if (typeof options.paysystemOn == 'undefined') {
        //   this.paysystemOn = false
        // } else if (options.paysystemOn == true) {
        //   this.paysystemOn = true
        // } else {this.paysystemOn = false}
        this.paymentSystems = {};
        console.log(options.paymentSystems);
        if (options.paymentSystems && typeof options.paymentSystems != 'undefined') {
            if (typeof options.paymentSystems.show == 'undefined') {
                this.paysystemOn = false;
            } else {
                this.paysystemOn = options.paymentSystems.show;
            }
            if (typeof options.paymentSystems.items != 'undefined') {
                for (var key = 0; key < options.paymentSystems.items.length; key++) {
                    if (options.paymentSystems.items[key] != false) {
                        if (options.paymentSystems.items[key].show) {
                            this.payCount++;
                        }
                        this.paymentSystems[options.paymentSystems.items[key].id] = {
                            show: options.paymentSystems.items[key].show,
                            details: options.paymentSystems.items[key].details
                        };
                    }
                }
            }
        } else {
            this.paysystemOn = false;
        }

        if (typeof options.deliveryInternals.show == 'undefined') {
            this.deliveryInternals.show = false
        } else if (options.deliveryInternals.show == true) {
            this.deliveryInternals.show = true
        } else {
            this.deliveryInternals.show = false
        }


        // for(var key in this.paysystem) {
        //   if(this.paysystem[key] != false){
        //     if(key == 'bankDetails' && !this.paysystem[key].show){
        //       continue;
        //     }
        //     this.payCount++;
        //   }
        // }

        if (options.google) {
            this.google = {
                reachPurchase: {
                    category: (options.google.reachPurchase && options.google.reachPurchase.category) || false,
                    action: (options.google.reachPurchase && options.google.reachPurchase.action) || false,
                    name: (options.google.reachPurchase && options.google.reachPurchase.name) || false,
                    value: (options.google.reachPurchase && options.google.reachPurchase.value) || false,
                },
                reachOrder: {
                    category: (options.google.reachOrder && options.google.reachOrder.category) || false,
                    action: (options.google.reachOrder && options.google.reachOrder.action) || false,
                    name: (options.google.reachOrder && options.google.reachOrder.name) || false,
                    value: (options.google.reachOrder && options.google.reachOrder.value) || false,
                },
            }
        }

        this.redirect = options.redirect || false
        this.hideOnClick = options.hideOnClick || false

        this.customTranslate = options.customTranslate || {}

        this.baseUrl = options.baseUrl || 'https://cart.creatura.club:8305/v4'
        this.language = options.language || 'english'
        this.language = app.languageShortcuts[this.language] || this.language
        this.currency = options.currency || '$'
        this.requireName = ('requireName' in options) ? options.requireName : true
        this.requirePhone = ('requirePhone' in options) ? options.requirePhone : true
        this.requireEmail = ('requireEmail' in options) ? options.requireEmail : false
        this.requireAddress = ('requireAddress' in options) ? options.requireAddress : false
        this.emailOrdersFrom = options.emailOrdersFrom
        this.emailOrdersTo = options.emailOrdersTo
        this.emailClientTo = options.emailClientTo || false
        this.license = server.license;

//alert(license);
        if (!this.emailOrdersTo)
            return callback(new Error("cartjs - `emailOrdersTo` not set, set it please!"))

        // // Waiting for document ready, `jQuery` can't be used because it may not be yet loaded.
        // var ensureDOMReady = function(callback){
        //   var interval = setInterval(function() {
        //     if (document.readyState === 'complete') {
        //       callback()
        //       clearInterval(interval)
        //     }
        //   }, 10)
        // }

        // Checking if it has been already initialized. It may happen if Shop uses
        // dynamic page updates, for example PJAX or Turbolinks.
        if (!this.initialized) {
            debug('initializing')
            // Loading resources.
            this.loadResources(fork(callback, bind(function () {
                // Initializing models and views.
                this.initializeModels()
                this.initializeViews()
                this.initialized = true
                callback()
            }, this)))
        } else {
            debug('re-initializing')
            // Unsubscribing all handlers.
            app.off()
            $(document).off('click', '.cart-buy-button')
            $(document).off('click', '.cart-button')

            // Re-initializing views.
            this.initializeViews()
        }


    }

    app.initializeModels = function () {
        this.cart = new app.Cart()
        this.cart.load()

        //console.log(window.location);

        this.contacts = new app.Contacts()
    }

    app.initializeViews = function () {
        this.cartButtonView = new app.CartButtonView(this.cart)
        this.cartButtonView.render()

        this.cartPopupView = new app.CartPopupView()
        this.cartPopupView.render()

        this.cartView = new app.CartView(this.cart)
        this.cartView.render()

        this.contactsView = new app.ContactsView(this.contacts, this.cart)
        this.contactsView.render()

        // Showing and hiding popup.
        app.on('toggle popup', bind(function () {
            if (this.cartPopupView.isActive()) this.cartPopupView.hide()
            else this.cartPopupView.show(this.cartView)
        }, this))

        app.on('hide popup', bind(function () {
            if (this.cartPopupView.isActive()) {
                this.cartPopupView.hide()
            }
        }, this))

        // Showing contact form.
        app.on('purchase', bind(function () {
            if (!app.minSumOn || this.cart.totalPrice() > app.minSum) {
                if (app.yandex.yandexID) {
                    var str = "yaCounter" + app.yandex.yandexID
                    var yandex = eval(str)
                    yandex.reachGoal(app.yandex.reachPurchase)
                }
                if (app.google.reachPurchase.category && app.google.reachPurchase.action && app.google.reachPurchase.name && app.google.reachPurchase.value) {
                    ga('send', 'event', app.google.reachPurchase.category, app.google.reachPurchase.action, app.google.reachPurchase.name, app.google.reachPurchase.value);
                }
                this.cartPopupView.show(this.contactsView)
                this.cartView.renderSendOrderButton();

                $('select#cart-delivery').change(function () {
                    app.cartView.renderSendOrderButton();
                })
                if ($("#cart-phone").length) {
                    $("#cart-phone").mask("+9 (999) 999 99 99");
                }
                $cartPurchaseButton = $('.cart-purchase-button');
                if ($cartPurchaseButton.length) {
                    $cartPurchaseButton.after(app.render('min-sum', app.minSum)).remove();
                }
                if ($("#cart-phone").length) {
                    $("#cart-phone").mask(app.phoneMask);
                }
            } else if (app.minSumOn && this.cart.totalPrice() < app.minSum) {
                if ($('.minSum').length == 0) {
                    if (app.minSumOn == true) {
                        $cartPurchaseButton = $('.cart-purchase-button');
                        if ($cartPurchaseButton.length) {
                            $cartPurchaseButton.after(app.render('min-sum', app.minSum));
                        }
                    }
                }
            }
        }, this))

        // Sending order.
        app.on('send order', bind(function () {
            if (app.contacts.isValid()) {

                // Preparing order.
                var order = {
                    price: this.cart.totalPrice(),
                    emailOrdersFrom: this.emailOrdersFrom,
                    emailOrdersTo: this.emailOrdersTo,
                    site: window.location.host,
                    currency: this.currency,
                    language: this.language,
                    emailClientTo: this.emailClientTo,
                    aboutShop: this.aboutShop
                }
                extend(order, this.contacts.toJSON())
                extend(order, this.cart.toJSON())

                order.paysystemDetail = "";
                order.paysystemDescription = "";
                if (order.paysystem == 'home') {
                    //order.paysystem = app.paysystem[order.paysystem];
                    order.paysystem = "";
                    order.paysystemDescription = this.customTranslate.systemHomeText || this.translation.systemHomeText;
                }

                if (order.paysystem == 'bankDetails') {
                    order.paysystemDescription = this.customTranslate.systemBankDetails || this.translation.systemBankDetails;
                    order.paysystemDetails = app.paymentSystems[order.paysystem].details;
                }

                order.deliveryDescription = "";
                if (order.delivery || order.delivery === 0) {
                    order.deliveryDescription = this.deliveryInternals.items[order.delivery].name;
                }

                //console.log(order);return false;

                // Clearing the cart and showing success message.
                this.cart.removeAll()

                var message = '';
                var pay = false;

                var currency = this.Paycurrency[this.currency] || 'USD';

                if (order.paysystem == 'paypal') {
                    message = '<div class="cart paysystem">' +
                        '<form action="https://www.paypal.com/cgi-bin/webscr" method="post">' +
                        '<input type="hidden" name="cmd" value="_xclick">  ' +
                        '<INPUT TYPE="hidden" name="charset" value="utf-8">' +
                        '<input type="hidden" name="business" value="' + app.paymentSystems.paypal.details + '">  ' +
                        '<input type="hidden" name="item_name" value="Pay this order">  ' +
                        '<input type="hidden" name="item_number" value="Order from ' + window.location.host + '">  ' +
                        '<input type="hidden" name="amount" value="' + order.price + '">  ' +
                        '<input type="hidden" name="no_shipping" value="0">  ' +
                        '<input type="hidden" name="no_note" value="1">  ' +
                        '<input type="hidden" name="currency_code" value="' + currency + '">  ' +
                        '<input type="hidden" name="lc" value="AU">  ' +
                        '<input type="hidden" name="bn" value="PP-BuyNowBF">  ' +
                        '<input type="hidden" name="return" value="' + (app.redirect || order) + '"/> ' +
                        '<button type="submit" name="submit" value="Перейти к оплате" class="btn btn-primary cart-purchase-button">Pay</button>' +
                        '</form>' +
                        '</div>';

                    pay = true;
                    order.paysystemDescription = app.customTranslate.systemPayPalText || app.translation.systemPayPalText;
                }

                if (order.paysystem == 'yandex') {
                    if (app.redirect) {
                        var r = '&successURL=' + app.redirect;
                    }
                    var text = encodeURIComponent('Заказ от клиента ' + (order.email || order.name) + ' на сумму ' + order.price);

                    message = '<div class="cart paysystem"><div class="yandex"><iframe frameborder="0" allowtransparency="true" scrolling="no" src="https://money.yandex.ru/embed/small.xml?account=' + app.paymentSystems.yandex.details + '&quickpay=small&yamoney-payment-type=on&button-text=02&button-size=s&button-color=white&targets=' + text + '&default-sum=' + order.price + '&mail=on&phone=on' + r + '" width="100" height="31"></iframe></div></div>';
                    pay = true;
                    order.paysystemDescription = app.customTranslate.systemYandexText || app.translation.systemYandexText;
                }

                if (order.paysystem == 'robokassa') {
                    pay = true;
                    order.paysystemDescription = app.customTranslate.systemRobokassa || app.translation.systemRobokassa;
                }

                if (order.paysystem == 'yandexkassa') {
                    pay = true;
                    order.paysystemDescription = app.customTranslate.systemYandexkassa || app.translation.systemYandexkassa;
                }

                if (order.paysystem == 'unifiedwallet') {
                    pay = true;
                    order.paysystemDescription = app.customTranslate.systemUnifiedWallet || app.translation.systemUnifiedWallet;
                }

                if (order.paysystem == 'webpay') {
                    pay = true;
                    order.paysystemDescription = app.customTranslate.systemWebPay || app.translation.systemWebPay;
                }

                if (order.paysystem == 'privat24') {
                    pay = true;
                    order.paysystemDescription = app.customTranslate.systemPrivat24 || app.translation.systemPrivat24;
                }

                if (!app.license) {
                    message = '<div class="cart">' + app.customTranslate.errorlicense + '</div>';
                }


                if (message == '') {
                    message = '<div class="cart"><div class="cart-message">'
                        + /*escapeHtml*/(t('orderSent')) + '</div></div>'
                }

                this.cartPopupView.show(message)

                if (!app.license) {
                    return false;
                }


                // Sending order to server.
                server.post('php/send_form.php?cart=true', order, bind(function (res) {
                    res = JSON.parse(res);
                    console.log('ordersfix result: ');
                    console.log(res);
                    if (app.yandex.yandexID) {
                        var str = "yaCounter" + app.yandex.yandexID
                        var yandex = eval(str)
                        yandex.reachGoal(app.yandex.reachOrder)
                    }
                    if (app.google.reachOrder.category && app.google.reachOrder.action && app.google.reachOrder.name && app.google.reachOrder.value) {
                        ga('send', 'event', app.google.reachOrder.category, app.google.reachOrder.action, app.google.reachOrder.name, app.google.reachOrder.value);
                    }
                    /*
                     if(err){
                     var message = '<div class="cart"><div class="cart-message cart-message-error">'
                     + escapeHtml(t('orderFailed')) + '</div></div>'
                     this.cartPopupView.show(message)
                     }
                     */
                    if (res.orderNumber) {
                        if (order.paysystem == 'robokassa') {
                            message = '<div class="cart paysystem">' +
                                '<form action="assets/robokassa.php" method="post">' +
                                '<INPUT TYPE="hidden" name="sum" value="' + order.price + '">  ' +
                                '<input type="hidden" name="description" value="Оплата товаров в магазине ' + window.location.host + '">  ' +
                                '<input type="hidden" name="currency" value="' + currency + '">  ' +
                                '<input type="hidden" name="order_number" value="' + res.orderNumber + '">  ' +
                                '<input type="hidden" name="email" value="' + order.emailClientTo + '">  ' +
                                '<button type="submit" name="submit" value="Перейти к оплате" class="btn btn-primary cart-purchase-button">Оплата</button>' +
                                '</form>' +
                                '</div>';

                            pay = true;
                            order.paysystemDescription = app.customTranslate.systemRobokassa || app.translation.systemRobokassa;
                        }

                        if (order.paysystem == 'webpay') {
                            message = '<div class="cart paysystem">' +
                                '<form action="assets/webpay.php" method="post">' +
                                '<INPUT TYPE="hidden" name="sum" value="' + order.price + '">  ' +
                                '<input type="hidden" name="description" value="Оплата товаров в магазине ' + window.location.host + '">  ' +
                                '<input type="hidden" name="currency" value="' + currency + '">  ' +
                                '<input type="hidden" name="order_number" value="' + res.orderNumber + '">  ' +
                                '<input type="hidden" name="email" value="' + order.emailClientTo + '">  ' +
                                '<button type="submit" name="submit" value="Перейти к оплате" class="btn btn-primary cart-purchase-button">Оплата</button>' +
                                '</form>' +
                                '</div>';

                            pay = true;
                            order.paysystemDescription = app.customTranslate.systemWebPay || app.translation.systemWebPay;
                        }

                        if (order.paysystem == 'privat24') {
                            message = '<div class="cart paysystem">' +
                                '<form action="assets/privat24.php" method="post">' +
                                '<INPUT TYPE="hidden" name="sum" value="' + order.price + '">  ' +
                                '<input type="hidden" name="description" value="Оплата товаров в магазине ' + window.location.host + '">  ' +
                                '<input type="hidden" name="currency" value="' + currency + '">  ' +
                                '<input type="hidden" name="order_number" value="' + res.orderNumber + '">  ' +
                                '<input type="hidden" name="email" value="' + order.emailClientTo + '">  ' +
                                '<button type="submit" name="submit" value="Перейти к оплате" class="btn btn-primary cart-purchase-button">Оплата</button>' +
                                '</form>' +
                                '</div>';

                            pay = true;
                            order.paysystemDescription = app.customTranslate.systemPrivat24 || app.translation.systemPrivat24;
                        }

                        if (order.paysystem == 'yandexkassa') {
                            message = '<div class="cart paysystem">' +
                                '<form action="assets/yandexkassa.php" method="post">' +
                                '<INPUT TYPE="hidden" name="sum" value="' + order.price + '">  ' +
                                '<input type="hidden" name="description" value="Оплата товаров в магазине ' + window.location.host + '">  ' +
                                '<input type="hidden" name="currency" value="' + currency + '">  ' +
                                '<input type="hidden" name="order_number" value="' + res.orderNumber + '">  ' +
                                '<input type="hidden" name="email" value="' + order.emailClientTo + '">  ' +
                                '<button type="submit" name="submit" value="Перейти к оплате" class="btn btn-primary cart-purchase-button">Оплата</button>' +
                                '</form>' +
                                '</div>';

                            pay = true;
                            order.paysystemDescription = app.customTranslate.systemYandexkassa || app.translation.systemYandexkassa;
                        }

                        if (order.paysystem == 'unifiedwallet') {
                            message = '<div class="cart paysystem">' +
                                '<form action="assets/unifiedwallet.php" method="post">' +
                                '<INPUT TYPE="hidden" name="sum" value="' + order.price + '">  ' +
                                '<input type="hidden" name="description" value="Оплата товаров в магазине ' + window.location.host + '">  ' +
                                '<input type="hidden" name="currency" value="' + currency + '">  ' +
                                '<input type="hidden" name="order_number" value="' + res.orderNumber + '">  ' +
                                '<input type="hidden" name="email" value="' + order.emailClientTo + '">  ' +
                                '<button type="submit" name="submit" value="Перейти к оплате" class="btn btn-primary cart-purchase-button">Оплата</button>' +
                                '</form>' +
                                '</div>';

                            pay = true;
                            order.paysystemDescription = app.customTranslate.systemUnifiedWallet || app.translation.systemUnifiedWallet;
                        }

                        this.cartPopupView.show(message)
                    }

                    if (app.redirect && pay == false) {
                        document.location.href = app.redirect;
                    }
                }, this))
            }
        }, this))

        // Showing popup with cart whenever user makes any change to cart.
        app.cart.on('add item', 'remove item', 'update item', bind(function () {
            this.cartPopupView.show(this.cartView)
            this.cartView.renderPurchaseButton();
        }, this))

        $("body > *").click(function (e) {
            var $target = $(e.target);

            if (
                $target.is('.Cart') ||
                $target.is('.cart-buy-button') ||
                $target.is('.cart-button') ||
                $target.is('.bootstrap-widget') ||
                $target.parents('.Cart').length ||
                $target.parents('.cart-buy-button').length ||
                $target.parents('.cart-button').length ||
                $target.parents('.bootstrap-widget').length
            )
                return;

            if (app.hideOnClick) {
                app.trigger('hide popup')
            }
        })

        // Processing click on the buy button.
        $(document).on('click', '.cart-buy-button', bind(function (e) {
            e.preventDefault()
            var $button = $(e.currentTarget)
            if ($button.data('instock') !== 'no' || typeof $button.data('instock') == 'undefined') {
                var price = $button.attr('data-price');
                this.cart.add({
                    name: $button.attr('data-name'),
                    price: app.number_format(price, 2, '.', ''),
                    quantity: parseInt($button.attr('data-quantity') || 1)
                })
                $('.bootstrap-widget').after(app.render('basket-animation', app.basketAnimation));
                if ($('.toBasket').length && app.basketAnimation) {
                    setTimeout(function () {
                        if (!$('.toBasket').hasClass('toBasketShow')) {
                            $('.toBasket').addClass('toBasketShow');
                        }
                    }, 1);
                    setTimeout(function () {
                        if ($('.toBasket').hasClass('toBasketShow')) {
                            $('.toBasket').removeClass('toBasketShow');
                        }
                    }, 1000);
                }
            }
            if (app.cart.totalPrice() > app.minSum) {
                if ($('.minSum').length > 0) {
                    $('.minSum').remove();
                }
            }
        }, this))


    }

    app.priceWithCurrency = function (price) {
        prefixed = ['$', '£', '€']
        if (prefixed.indexOf(this.currency.toLowerCase()) >= 0) return app.currency + ' ' + app.number_format(price, 2, '.', ' ')
        else if (price == 0) return ' '
        else return app.number_format(price, 2, '.', ' ') + ' ' + app.currency
    }

    // # Models.
    //
    // Cart.
    app.Cart = function (items) {
        this.items = items || []
    }
    var proto = app.Cart.prototype
    Events(proto)

    proto.load = function () {
        var jsonString = db.get('cart-items')
        debug('loading cart', jsonString)
        if (jsonString) {
            var json = JSON.parse(jsonString)
            this.items = json.items || []
        }
    }

    proto.save = function () {
        db.set('cart-items', JSON.stringify(this))
    }

    proto.toJSON = function () {
        return {items: JSON.parse(JSON.stringify(this.items))}
    }

    proto.removeAll = function () {
        var length = this.items.length
        for (var i = 0; i < length; i++)
            this.remove(this.items[this.items.length - 1])
    }

    proto.totalPrice = function () {
        var sum = 0
        each(this.items, function (item) {
            sum = sum + item.price * item.quantity
        })
        var selectedDeliveryPrice = 0;
        if ($("#cart-delivery").length && app.deliveryInternals.recalculateTotalSum) {
            selectedDeliveryPrice = $("#cart-delivery option:selected").data('price');
        }
        return sum + selectedDeliveryPrice
    }

    proto.totalQuantity = function () {
        var sum = 0
        each(this.items, function (item) {
            sum = sum + item.quantity
        })
        return sum
    }

    proto.isEmpty = function () {
        return this.items.length == 0
    }

    proto.add = function (item) {

        var i = find(this.items, function (i) {
            return i.name == item.name
        })
        if (i >= 0) {
            var existingItem = this.items[i]
            this.update(item.name, {quantity: (existingItem.quantity + item.quantity)})
        } else {
            this.validateItem(item)
            this.items.push(item)
            this.save()
            this.trigger('add item', item)
        }
    }

    proto.remove = function (nameOrItem) {
        var name = nameOrItem.name || nameOrItem
        //var i = find(this.items, function(i){return i.name = name})

        var i;

        this.items.forEach(function (item, num, arr) {
            if (item.name == name) {
                i = num;
            }
        });

        if (i >= 0) {
            var item = this.items[i]
            this.items.splice(i, 1)
            this.save()
            this.trigger('remove item', item)
        }
    }

    proto.update = function (name, attrs) {
        var i = find(this.items, function (i) {
            return i.name == name
        })
        if (i >= 0) {
            var item = this.items[i]
            this.validateItem(extend({}, item, attrs))
            extend(item, attrs)
            this.save()
            this.trigger('update item', item)
        }
    }

    proto.validateItem = function (item) {
        if (!item.name) throw new Error('no name!')
        if (item.price < 0) throw new Error('no price!')
        if (!((item.quantity > 0) || (item.quantity === 0))) throw new Error('no quantity!')
    }

    // Contacts.
    app.Contacts = function () {
        extend(this, {name: '', phone: '', email: '', address: '', paysystem: '', errors: {}})
    }
    var proto = app.Contacts.prototype
    Events(proto)

    proto.set = function (attrs) {
        extend(this, attrs)
        this.validate()
        this.trigger('update', this)
        // this.save()
    }

    proto.validate = function () {
        this.errors = {}
        if (app.requireName && !this.name) this.errors.name = ["can't be empty"]
        if (app.requirePhone) {
            var errors = []
            if (!this.phone) errors.push("can't be empty")
            if (!/^((\+?\d{1,})[\- ]?)?(\(?\d{2,3}\)?[\- ]?)?[\d\- ]{7,10}$/.test(this.phone)) errors.push("invalid phone number")
            if (errors.length > 0) this.errors.phone = errors
        }
        if (app.requireEmail && !this.email) this.errors.email = ["can't be empty"]
        var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if (app.requireEmail && !regex.test(this.email)) this.errors.email = ["invalid email"]
        if (app.requireAddress && !this.address) this.errors.address = ["can't be empty"]
        return this.errors
    }

    proto.toJSON = function () {
        var data = {}
        if (app.requireName)    data.name = this.name
        if (app.requirePhone)   data.phone = this.phone
        if (app.requireEmail)   data.email = this.email
        if (app.requireAddress) data.address = this.address
        data.paysystem = this.paysystem
        data.delivery = this.delivery
        return data
    }

    proto.isValid = function () {
        return isObjectEmpty(this.errors)
    }

    // # Views.
    //
    // Cart button.
    app.CartButtonView = function (cart) {
        this.cart = cart
        bindAll('render', this)
        this.cart.on('add item', 'remove item', 'update item', this.render)

        $(document).on('click', '.cart-button', function (e) {
            e.preventDefault()
            app.trigger('toggle popup')
        })
    }
    var proto = app.CartButtonView.prototype

    proto.render = function () {
        var $button = $('.cart-button')
        var quantity = 0;
        if (this.cart.items.length > 0) {
            for (var i = 0; i < this.cart.items.length; i++) {
                quantity += this.cart.items[i].quantity;
            }
            ;
        }
        $button.find('.cart-button-quantity').text(quantity)
        $button.find('.cart-button-label').text(t('cartButtonLabel', {count: quantity}))
        $button.removeClass('cart-button-empty').removeClass('cart-button-not-empty')
        $button.addClass(this.cart.isEmpty() ? 'cart-button-empty' : 'cart-button-not-empty')
        $button.show()
    }

    // Popup.
    app.CartPopupView = function () {
        this._isActive = false
        bindAll('render', 'show', 'hide', 'isActive', this)
    }
    var proto = app.CartPopupView.prototype

    proto.render = function () {
    }

    // Bootstrap Popup doesn't fit well into dynamic approach we using, so logic in
    // the `render` method is a little tricky.
    proto.show = function (content) {
        var contentEl = content.$el || content
        if (this.isActive()) {
            if (this.content === content) return
            else {
                // We already have an opened Popup and need only to change its content.
                var $popoverContent = $('body > .bootstrap-widget:not(.toBasket) .popover-content')
                $popoverContent.find('> *').detach()
                $popoverContent.append(contentEl)
                this.content = content
            }
        } else {
            this._isActive = true
            this.content = content

            // Bootstrap styles will be applied only to elements inside of `.bootstrap` namespace,
            // creating such namespace if it's not yet created.
            if (!($('.bootstrap-widget').size() > 0))
                $('<div class="bootstrap-widget"></div>').appendTo('body')

            $('.cart-button').popover({
                // title     : '',
                content: contentEl,
                html: true,
                placement: 'bottom',
                container: 'body > .bootstrap-widget',
                trigger: 'manual'
            })


            $('.cart-button').popover('show');


            if (app.positionPopover != 'center') {
                var popoverWidth = $('.popover .popover-content').outerWidth();
                var buttonWidth = $('.cart-button').outerWidth();
                var delta = (popoverWidth - buttonWidth) / 2;

                if (app.positionPopover == 'left') {
                    $('.popover .popover-content').css({
                        left: (popoverWidth - buttonWidth) / 2,
                    })
                }
                if (app.positionPopover == 'right') {
                    $('.popover .popover-content').css({
                        right: (popoverWidth - buttonWidth) / 2,
                    })
                }
            }

            $(window).resize(function () {
                /*$('.cart-button').popover('destroy')*/
                var basketElem = /*"div.rounded-corners.grpelem"*//*"div#u75"*/$(".cart-button").parent();

                var popoverAllElems = "div.popover.fade.bottom.in";
                if (app.positionPopover == "right") {
                    var basketRightPoint = $(basketElem).offset().left + $(basketElem).width();
                    $(popoverAllElems).offset({left: (basketRightPoint - $(popoverAllElems).width())});
                } else if (app.positionPopover == "center" || app.positionPopover == "left") {
                    var basketRightPoint = $(basketElem).offset().left + $(basketElem).width() / 2;
                    $(popoverAllElems).offset({left: (basketRightPoint - $(popoverAllElems).width() / 2)});
                }
            })
        }

        if (app.positionPopover == "right") {
            if ($('.popover-content').length) {
                var right = parseFloat($('.popover-content').css('right'));
                $('.popover-content').css('right', 'auto');
                if ($('.popover.fade.bottom.in').length) {
                    $('.popover.fade.bottom.in').css('left', parseFloat($('.popover.fade.bottom.in').css('left')) - right);
                    $('.popover.fade.bottom.in').find('.arrow').css('left', 'auto');
                    $('.popover.fade.bottom.in').find('.arrow').css('right', right);
                }
            }
        } else if (app.positionPopover == "center" || app.positionPopover == "left") {
            if ($('.popover-content').length) {
                var right = parseFloat($('.popover-content').css('right'));
                $('.popover-content').css('right', 'auto');
                if ($('.popover.fade.bottom.in').length) {
                    $('.popover.fade.bottom.in').css('left', parseFloat($('.popover.fade.bottom.in').css('left')) - right);
                    //$('.popover.fade.bottom.in').find('.arrow').css('left', 'auto');
                    //$('.popover.fade.bottom.in').find('.arrow').css('right', right);
                }
            }
        }
    }

    proto.hide = function () {
        $('.cart-button').popover('destroy')
        this._isActive = false
        this.content = null
    }

    proto.isActive = function () {
        // We need to check also if element exists because site may use dynamic page update and
        // tools like PJAX or Ruby on Rails Turbolinks.
        return this._isActive && ($('.bootstrap-widget .popover').size() > 0)
    }

    // Cart.
    app.CartView = function (cart) {
        this.cart = cart
        bindAll('render', 'renderPurchaseButton', 'renderAddItem', 'renderRemoveItem'
            , 'renderUpdateItem', 'scrollQuantity', 'updateQuantity', 'removeItem', this)

        this.cart.on('add item', 'remove item', 'update item', this.renderPurchaseButton)
        this.cart.on('add item', this.renderAddItem)
        this.cart.on('remove item', this.renderRemoveItem)
        this.cart.on('update item', this.renderUpdateItem)

        this.$el = $('<div class="cart"></div>')
        this.$el.on('keyup', '.cart-item-quantity', this.scrollQuantity)
        this.$el.on('change', '.cart-item-quantity', this.updateQuantity)
        this.$el.on('click', '.cart-item-remove', this.removeItem)
        this.$el.on('click', '.cart-purchase-button', function (e) {
            e.preventDefault()
            app.trigger('purchase')
        })
    }
    var proto = app.CartView.prototype

    proto.render = function () {
        this.$el.html(app.render('cart', this.cart))
        this.renderPurchaseButton()
    }

    proto.renderPurchaseButton = function () {
        var $purchaseButton = this.$el.find('.cart-purchase-button')
        if (this.cart.totalQuantity() > 0) $purchaseButton.removeAttr('disabled')
        else $purchaseButton.attr({disabled: 'disabled'})
        $purchaseButton.html(app.render('cart-purchase-button', this.cart.totalPrice()))
    }

    proto.renderSendOrderButton = function () {
        var $sendOrderButton = $('.cart .cart-send-order-button')
        //console.log($sendOrderButton);
        if (this.cart.totalQuantity() > 0) $sendOrderButton.removeAttr('disabled')
        else $sendOrderButton.attr({disabled: 'disabled'})
        $sendOrderButton.find('.cart-send-order-button-price').html(app.priceWithCurrency(this.cart.totalPrice()))
    }

    proto.renderAddItem = function (item) {
        if (!app.license) {

            return false;
        }
        var $cartItems = this.$el.find('.cart-items')
        if ($cartItems.size() > 0) $cartItems.append(app.render('cart-item', item))
        else this.render()
    }

    proto.renderRemoveItem = function (item) {
        if (this.cart.items.length == 0) this.render()
        //this.$el.find('.cart-item[data-name="' + escapeHtml(item.name) + '"]').remove()
        this.$el.find('.cart-item[data-name="' + (item.name) + '"]').remove()
    }

    proto.renderUpdateItem = function (item) {
        // We can't update the full item element because if user has focus on input - after
        // update that focus will be lost.
        // We using the fact that name and price of row never will be changed, only quantity
        // will, so we will update only quantity here.
        //var $input = this.$el.find('.cart-item-quantity[data-name="' + escapeHtml(item.name) + '"]')
        var $input = this.$el.find('.cart-item-quantity[data-name="' + (item.name) + '"]')
        if (parseInt($input.val()) != item.quantity && $input.length) {
            var input = $input[0]
            var selectionStart = input.selectionStart
            var selectionEnd = input.selectionEnd
            $input.val(item.quantity)
            input.setSelectionRange(selectionStart, selectionEnd)
        }
        if (app.cart.totalPrice() > app.minSum) {
            if ($('.minSum').length > 0) {
                $('.minSum').remove();
            }
            // } else {
            //   if($('.minSum').length == 0){
            //     $cartPurchaseButton = $('.cart-purchase-button');
            //       if($cartPurchaseButton.length){
            //         $cartPurchaseButton.after(app.render('min-sum', app.minSum));
            //       }
            //   }
        }
    }

    // Update quantity with Up or Down buttons.
    proto.scrollQuantity = function (e) {
        e.preventDefault()
        var delta = 0
        if (e.keyCode == 38) delta = 1  // Up
        if (e.keyCode == 40) delta = -1 // Down
        if (delta === 0) return

        var $input = $(e.currentTarget)
        var name = $input.attr('data-name')
        var quantity = parseInt($input.val()) + delta
        if (quantity >= 0) this.cart.update(name, {quantity: quantity})
    }

    proto.updateQuantity = function (e) {
        e.preventDefault()
        var $input = $(e.currentTarget)
        var name = $input.attr('data-name')
        var quantity = parseInt($input.val())
        if (quantity >= 0) this.cart.update(name, {quantity: quantity})
    }

    proto.removeItem = function (e) {
        e.preventDefault()
        var $removeButton = $(e.currentTarget)
        this.cart.remove($removeButton.attr('data-name'))
    }

    app.template('cart', function (add, cart) {
        add('<div class="cart">')
        //alert('show' + app.license);
        if (!app.license) {
            add('<div class="cart-message">Срок действия пробной версии виджета закончился! Перейдите по <a href="//muse-cart.ru/buy_full.html?utm_source=demosite&utm_medium=block_banner&utm_campaign=demo_link" target="_blank">ссылке</a> чтобы узнать как активировать полную версию.</div>')
        }
        else {
            if (cart.items.length > 0) {
                // Items.
                add('<div class="cart-items">')
                each(cart.items, function (item) {
                    add(app.render('cart-item', item))
                })
                add('</div>')

                // Purchase button.
                add('<button class="btn btn-primary cart-purchase-button" type="button"></button>')

            } else add('<div class="cart-message">' + /*escapeHtml*/(t('emptyCart')) + '</div>')
        }
        add('</div>')
    })

    app.template('min-sum', function (add, sum) {
        add('<div class="minSum">' + 'Минимальная сумма заказа ' + app.priceWithCurrency(sum) + '. Пожалуйста, добавьте товаров еще на сумму ' + app.priceWithCurrency(sum - app.cart.totalPrice()) + '.' + '</div>')
    })

    app.template('basket-animation', function (add, basketAnimation) {
        if (!$('.toBasket').length) {
            add('<div class="bootstrap-widget toBasket"><div class="popover-content">' + 'Товар добавлен в корзину' + '</div></div>')
        }
    })

    app.template('cart-purchase-button', function (add, totalPrice) {
        add('<span class="cart-purchase-button-label">' + /*escapeHtml*/(t('purchaseButtonTitle'))
            + '</span>')
        add('<span class="cart-purchase-button-price">'
            + app.priceWithCurrency(totalPrice) + '</span>')
    })

    app.template('cart-item', function (add, item) {
        add('<div class="cart-item" data-name="' + /*escapeHtml*/(item.name) + '">')
        add('<div class="cart-item-name">' + /*escapeHtml*/(item.name) + '</div>')
        add('<a href="#" class="cart-item-remove" data-name="' + /*escapeHtml*/(item.name)
            + '">&times;</a>')
        add('<input class="cart-item-quantity form-control" type="text" value="'
            + item.quantity + '" data-name="' + /*escapeHtml*/(item.name) + '">')
        add('<div class="cart-item-multiply-sign">&times;</div>')
        // If price with currency is too big showing price only.
        var priceWithCurrency = app.priceWithCurrency(item.price)
        if (priceWithCurrency.length > 4) priceWithCurrency = app.number_format(item.price, 2, '.', ' ')
        add('<div class="cart-item-price">' + priceWithCurrency + '</div>')
        add('<div class="cart-clearfix"></div>')
        add('</div>')
    })

    // Contact form.
    app.ContactsView = function (contacts, cart) {
        this.contacts = contacts
        this.cart = cart
        bindAll('render', 'renderUpdate', 'updateInput', this)
        this.contacts.on('update', this.renderUpdate)
        this.cart.on('add item', 'remove item', 'update item', this.render)

        this.$el = $('<div class="cart"></div>')
        this.$el.on('change', 'input, textarea', this.updateInput)
        // this.$el.on('change', 'textarea', this.updateTextarea)
        var sendOrder = bind(function (e) {
            e.preventDefault()
            this.contacts.set(this.getValues())
            this.showAllErrors = true
            this.renderUpdate()
            app.trigger('send order')
        }, this)
        this.$el.on('click', '.cart-send-order-button', sendOrder)
        this.$el.on('submit', 'form', sendOrder)

        // When user enter values in form for the first time not all errors
        // should be shown, but only on those fields he already touched.
        // But, if he tries to submit form - errors on all fields should be
        // shown.
        this.showAllErrors = false
    }
    var proto = app.ContactsView.prototype

    proto.render = function () {

        this.$el.html(app.render('contact-form'
            , this.contacts, this.cart.totalPrice(), this.showAllErrors))
    }

    // We can't rerender the whole form because the focus and selection will be lost,
    // making only small changes and only if they are neccessarry.
    proto.renderUpdate = function () {
        this.$el.find('.form-group').each(bind(function (i, e) {
            var $group = $(e)
            var $input = $group.find('input, textarea')
            var input = $input[0]
            var name = $input.attr('name')

            // Setting error or success.
            $group.removeClass('has-error').removeClass('has-success')
            // Showing errors only if field has been changed.
            if (this.showAllErrors || ($input.attr('data-changed') == 'changed'))
                $group.addClass(this.contacts.errors[name] ? 'has-error' : 'has-success')

            // Updating value.
            if ($input.val() !== this.contacts[name]) {
                var selectionStart = input.selectionStart
                var selectionEnd = input.selectionEnd
                $input.val(this.contacts[name])
                input.setSelectionRange(selectionStart, selectionEnd)
            }
        }, this))
    }

    proto.updateInput = function (e) {
        e.preventDefault()
        var $input = $(e.currentTarget)
        // We need this marking to show errors only on fields that has been changed.
        $input.attr('data-changed', 'changed')
        var attrs = {}
        attrs[$input.attr('name')] = $input.val()
        this.contacts.set(attrs)
    }

    proto.getValues = function () {
        var attrs = {}
        this.$el.find('input, textarea, select').each(bind(function (i, e) {
            var $input = $(e)
            attrs[$input.attr('name')] = $input.val()
        }, this))
        return attrs
    }

    app.template('contact-form', function (add, contacts, totalPrice, showAllErrors) {
        add('<form role="form">')
        var errorClass = function (attribute) {
            if (contacts.errors[attribute]) return ' has-error'
            else return showAllErrors ? ' has-success' : ''
        }


        $(".cart-buy-button[data-instock='no']").each(function (i, elem) {
            $(this).parent().addClass("noInStock")
            $(this).html(app.customTranslate.systemNoInStockText || app.translation.systemNoInStockText);
        })


        // Name field.
        if (app.requireName) {
            add('<div class="form-group' + errorClass('name') + '">')
            add('<label class="control-label" for="cart-name">'
                + /*escapeHtml*/(t('nameFieldLabel')) + '</label>')
            add('<input type="text" name="name" class="form-control" id="cart-name"'
                + ' placeholder="' + /*escapeHtml*/(t('nameFieldPlaceholder')) + '"'
                + ' required value="' + contacts.name + '">')
            add('</div>')
        }

        // Phone field.
        if (app.requirePhone) {
            add('<div class="form-group' + errorClass('phone') + '">')
            add('<label class="control-label" for="cart-phone">'
                + /*escapeHtml*/(t('phoneFieldLabel')) + '</label>')
            add('<input type="text" name="phone" class="form-control" id="cart-phone"'
                + ' placeholder="' + /*escapeHtml*/(t('phoneFieldPlaceholder')) + '"'
                + ' required value="' + contacts.phone + '">')
            add('</div>')
        }

        // Email field.
        if (app.requireEmail) {
            add('<div class="form-group' + errorClass('email') + '">')
            add('<label class="control-label" for="cart-email">'
                + /*escapeHtml*/(t('emailFieldLabel')) + '</label>')
            add('<input type="text" name="email" class="form-control" id="cart-email"'
                + ' placeholder="' + /*escapeHtml*/(t('emailFieldPlaceholder')) + '"'
                + ' required value="' + contacts.email + '">')
            add('</div>')
        }


        // Address field.
        if (app.requireAddress) {
            add('<div class="form-group' + errorClass('address') + '">')
            add('<label class="control-label" for="cart-address">'
                + /*escapeHtml*/(t('addressFieldLabel')) + '</label>')
            add('<textarea type="text" name="address" class="form-control" id="cart-address"'
                + ' placeholder="' + /*escapeHtml*/(t('addressFieldPlaceholder')) + '"'
                + ' required rows="3">' + contacts.address + '</textarea>')
            add('</div>')
        }

        // PaySystem
        //console.log(app);
        if (app.payCount > 0 && app.paysystemOn) {
            add('<div class="form-group' + errorClass('paysystem') + '">')
            add('<label class="control-label" for="cart-paysystem">'
                + /*escapeHtml*/(t('paysystemFieldLabel')) + '</label>')
            add('<select name="paysystem" class="form-control" id="cart-paysystem">');

            for (var key in app.paymentSystems) {
                //console.log(app.customTranslate);
                if (app.paymentSystems[key].show != false) {
                    if (key == 'home') {
                        add('<option value="' + key + '">' + (app.customTranslate.systemHomeText || app.translation.systemHomeText) + '</option>');
                    }
                    if (key == 'paypal') {
                        add('<option value="' + key + '">' + (app.customTranslate.systemPayPalText || app.translation.systemPayPalText) + '</option>');
                    }
                    if (key == 'yandex') {
                        add('<option value="' + key + '">' + (app.customTranslate.systemYandexText || app.translation.systemYandexText) + '</option>');
                    }
                    if (key == 'bankDetails') {
                        add('<option value="' + key + '">' + (app.customTranslate.systemBankDetails || app.translation.systemBankDetails) + '</option>');
                    }
                    if (key == 'robokassa') {
                        add('<option value="' + key + '">' + (app.customTranslate.systemRobokassa || app.translation.systemRobokassa) + '</option>');
                    }
                    if (key == 'webpay') {
                        add('<option value="' + key + '">' + (app.customTranslate.systemWebPay || app.translation.systemWebPay) + '</option>');
                    }
                    if (key == 'privat24') {
                        add('<option value="' + key + '">' + (app.customTranslate.systemPrivat24 || app.translation.systemPrivat24) + '</option>');
                    }
                    if (key == 'yandexkassa') {
                        add('<option value="' + key + '">' + (app.customTranslate.systemYandexkassa || app.translation.systemYandexkassa) + '</option>');
                    }
                    if (key == 'unifiedwallet') {
                        add('<option value="' + key + '">' + (app.customTranslate.systemUnifiedWallet || app.translation.systemUnifiedWallet) + '</option>');
                    }
                }
            }

            add('</select>')
            add('</div>')
        }


        // Delivery
        if (app.deliveryCount > 0 && app.deliveryInternals.show) {
            add('<div class="form-group' + errorClass('delivery') + '">')
            add('<label class="control-label" for="cart-delivery">'
                + /*escapeHtml*/(t('deliveryFieldLabel')) + '</label>')
            add('<select name="delivery" class="form-control" id="cart-delivery">');

            app.deliveryInternals.items.forEach(function (obj, key) {
                if (obj.show && obj.name && obj.price !== undefined && obj.price !== 0) {
                    add('<option value="' + key + '" data-price="' + obj.price + '">' + obj.name + ' - ' + app.priceWithCurrency(obj.price) + '</option>');
                } else if (obj.show && obj.name && obj.price == undefined) {
                    add('<option value="' + key + '" data-price="' + obj.price + '">' + obj.name + '</option>');
                } else if (obj.show && obj.name && obj.price == 0) {
                    add('<option value="' + key + '" data-price="' + obj.price + '">' + obj.name + '</option>');
                }
            })

            add('</select>')
            add('</div>')
        }

        // Buy button.
        add('<button type="button" class="btn btn-primary cart-send-order-button">')
        add('<span class="cart-send-order-button-label">' + /*escapeHtml*/(t('buyButtonTitle'))
            + '</span>')
        add('<span class="cart-send-order-button-price">' + app.priceWithCurrency(totalPrice)
            + '</span>')
        add('</button>')
        add('</form>')
    })


})()